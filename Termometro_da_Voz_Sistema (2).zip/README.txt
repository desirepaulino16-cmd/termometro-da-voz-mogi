=============================================================
  TERMÔMETRO DA VOZ — Sistema ao vivo
  Workshop · Comunicação Assertiva · Grupo Presença
=============================================================

ARQUIVOS:
  projetor.html  → Abrir no computador conectado ao projetor
  celular.html   → Link para os participantes no celular
  relatorio.html → Relatório após encerrar a sessão

PASSO A PASSO:

1. REGRAS FIREBASE (OBRIGATÓRIO)
   Acesse: console.firebase.google.com
   → Seu projeto → Realtime Database → Regras
   Cole e publique:
   {
     "rules": {
       ".read": true,
       ".write": true
     }
   }

2. ABRIR O PROJETOR
   Abra projetor.html no navegador do computador
   → Digite o código da sessão (ex: PRESENCA01)
   → Clique em "Iniciar sessão"
   → Projete a tela: aparece QR code + código

3. PARTICIPANTES
   Abram celular.html pelo celular
   → Digitem o código da sessão
   → Respondem as 11 perguntas

4. DURANTE A APRESENTAÇÃO
   No projetor: navegue entre as perguntas com os botões
   As barras atualizam a cada 1,5 segundos automaticamente

5. ENCERRAR
   Clique "Encerrar sessão" no projetor
   O relatório abre automaticamente

6. RELATÓRIO
   Abra relatorio.html e digite o código
   Clique "Imprimir / PDF" para salvar

SUPORTE: 90 respondentes simultâneos (Firebase gratuito)
Firebase: termometro-da-voz-promotora-default-rtdb.firebaseio.com
=============================================================
